using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Kodo;

public sealed class TypedLangRulesProvider : ILangRulesProvider
{
    public LangRulesProviderInfo Info { get; } = new(
        "Legacy LangRules adapter", "2.1.0",
        LangRulesCapability.Tokens | LangRulesCapability.Symbols |
        LangRulesCapability.Diagnostics | LangRulesCapability.SemanticAnalysis |
        LangRulesCapability.Completions | LangRulesCapability.Definition |
        LangRulesCapability.References | LangRulesCapability.Hover |
        LangRulesCapability.SignatureHelp | LangRulesCapability.CodeActions |
        LangRulesCapability.Formatting | LangRulesCapability.EmbeddedRegions);

    private static object? Call(string name, params object?[] args) =>
        typeof(LangRules).GetMethods(BindingFlags.Public | BindingFlags.Static)
            .FirstOrDefault(m => m.Name == name && m.GetParameters().Length == args.Length)
            ?.Invoke(null, args);

    private static IEnumerable<object> Items(object? value) => value is IEnumerable e ? e.Cast<object>() : Array.Empty<object>();
    private static T P<T>(object value, string name, T fallback = default!)
    {
        var p = value.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance);
        return p?.GetValue(value) is T result ? result : fallback;
    }
    private static int Line(string code, int start) => code.Take(Math.Clamp(start, 0, code.Length)).Count(c => c == '\n');

    public IReadOnlyList<LangRuleToken> Tokenize(string code) => Items(Call("Tokenize", code)).Select(x => new LangRuleToken(P<object>(x,"Kind")?.ToString() ?? "", P(x,"Text",""), P(x,"Start",0), P(x,"Length",0), P(x,"Scope",""), P(x,"Color",""))).ToArray();
    public IReadOnlyList<LangRuleSymbol> AnalyzeSymbols(string code) => Items(Call("AnalyzeSymbols", code)).Select(x => new LangRuleSymbol(P(x,"Name",""), P<object>(x,"Kind")?.ToString() ?? "", P(x,"Line",Line(code,P(x,"Start",0))), P(x,"Start",0), P(x,"Length",0), P(x,"IsDeclaration",false))).ToArray();
    public IReadOnlyList<LangRuleDiagnostic> AnalyzeSyntax(string code) => Diagnostics(Call("AnalyzeSyntax", code));
    public IReadOnlyList<LangRuleDiagnostic> AnalyzeSemantics(string code) => Diagnostics(Call("AnalyzeSemantics", code));
    private static IReadOnlyList<LangRuleDiagnostic> Diagnostics(object? value) => Items(value).Select(x => new LangRuleDiagnostic(P(x,"Start",0), P(x,"Length",1), P(x,"Message",""), P(x,"Severity","warning"), P(x,"Code",""), P(x,"Source","LangRules"))).ToArray();
    public IReadOnlyList<string> GetCompletions(string code, int offset, string prefix) => Items(Call("GetCompletionsForPrefix", prefix, code)).Select(x => x.ToString() ?? "").ToArray();
    public LangRuleLocation? FindDefinition(string code, int offset) => null;
    public IReadOnlyList<LangRuleLocation> FindReferences(string code, int offset) => Array.Empty<LangRuleLocation>();
    public LangRuleHover? GetHover(string code, int offset) => null;
    public LangRuleSignatureHelp? GetSignatureHelp(string code, int offset) => null;
    public IReadOnlyList<LangRuleCodeAction> GetCodeActions(string code, int offset) => Array.Empty<LangRuleCodeAction>();
    public string? FormatDocument(string code) => Call("FormatDocument", code) as string;
    public IReadOnlyList<LangRuleEmbeddedRegion> GetEmbeddedRegions(string code) => Array.Empty<LangRuleEmbeddedRegion>();
}
